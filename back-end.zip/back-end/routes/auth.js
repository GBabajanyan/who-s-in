//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
const router = require('express').Router()
const User = require('../model/user')
const jwt = require('jsonwebtoken');
const bycript = require("bcryptjs")
const nodemailer = require('nodemailer')
const sendgrid = require('nodemailer-sendgrid-transport')
const checkToken = require('./checkToken')


const transporter = nodemailer.createTransport(sendgrid({
    auth: { api_key: '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' }
}))

router.post('/signin', async (req, res) => {

    const emailExists = await User.findOne({ email: req.body.email })
    if (!emailExists) {
        res.status(400).send({ message: 'Please register' })
        return
    }
    const areSame = await bycript.compare(req.body.password, emailExists.password)
    if (!areSame) {
        res.status(400).send({ message: 'Password is wrong' })
        return
    }
    const token = jwt.sign({ id: emailExists._id }, 'tumo_students');
    res.send({ auth_token: token })

})

router.post('/signup', async (req, res) => {
    const emailExists = await User.findOne({ email: req.body.email })

    if (emailExists) {
        res.status(400).send({ message: 'Email already exists' })
    }
    else {
        const hashPassword = await bycript.hash(req.body.password, 10)
        const user = new User({
            name: req.body.name,
            email: req.body.email,
            poh: req.body.poh,
            avatar: req.body.avatar,
            password: hashPassword,
        })
        try {
            const data = await user.save()
            await transporter.sendMail({
                to: req.body.email,
                from: 'gevorg.b.y@gmail.com',
                subject: "hello",
                text: "Hello",
                html: `<հ1 style='color:blue'>Hello ${req.body.name}</h1>`
            })
            console.log(data);
            res.send(data)
        } catch (error) {
            console.log(error);
            res.status(400).send({ message: 'Something went wrong' })
        }
    }

})

router.get('/profile', checkToken, async (req, res) => {
    try {
        const data = await User.find({_id:req.user})
        res.send(data)
    } catch (error) {
        res.status(400).send({ message: "Plase try again" })
        console.log(error);
    }
})

router.get('/guestInfo/:userId',async(req,res)=>{
    const userId = req.params.userId
    try {
        const data = await User.find({_id: userId})
        res.send(data)
    } catch (error) {
        res.status(400).send({message: "Plase try again"})
        console.log(error);
    }       
})


module.exports = router


