const router = require('express').Router()  
const checkToken = require('./checkToken')
const Post = require('../model/post')


router.get('/',async(req,res)=>{ 
        try {
            const data = await Post.find().populate("userId", "date name email poh avatar")
            res.send(data)
        } catch (error) {
            res.status(400).send({message: "Cant find any posts"})
            console.log(error);
        }
})

router.get('/post/:id',async(req,res)=>{
    const id = req.params.id
    try {
        const data = await Post.findById(id)
        res.send(data)
    } catch (error) {
        res.status(400).send({message: "Plase try again"})
        console.log(error);
    }

})

router.post('/add',checkToken, async(req,res)=>{
    const post = new Post({
        toDo: req.body.toDo,
        place: req.body.place,
        meetingTime: req.body.meetingTime,
        timeOut: req.body.timeOut,        
        userId: req.user
    })
        
    try {
        const data = await post.save().populate("userId", "date name email poh avatar")
        res.send(data)
    } catch (error) {
        console.log(error);
        res.status(400).send('Please try again')
    }
     
})

router.delete('/del/:id',checkToken, async(req,res)=>{
    const id = req.params.id     
   
    try {
        const data = await Post.findById(id)
       if (data.userId ==req.user) {
            const datapost = await Post.findByIdAndDelete(id)
            res.send(datapost)
        }
        else{
            console.log('ne parol');
        }
    } catch (error) {
        res.status(400).send({message: "Cannot delete,Plase try again"})
        console.log(error);
    }
})

router.get('/guestPosts/:userId',async(req,res)=>{
    const userId = req.params.userId
    try {
        const data = await Post.find({userId: userId})
        res.send(data)
    } catch (error) {
        res.status(400).send({message: "Plase try again"})
        console.log(error);
    }   
})

router.get('/profile', checkToken, async (req, res) => {
    try {
        const data = await Post.find({userId: req.user})
        res.send(data)
    } catch (error) {
        res.status(400).send({message: "Plase try again"})
        console.log(error);
    }
})

module.exports  = router