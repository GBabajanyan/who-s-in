const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const app = express()
const cors = require('cors')

app.use(cors())
app.use(bodyParser.json())


mongoose.connect('mongodb+srv://tumo:tumo1234@cluster0-5wgii.mongodb.net/whosIn?retryWrites=true&w=majority',
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    },
    () => {
        console.log("Connect to DB");
    })


const authRoute = require('./routes/auth')
const postRoute = require('./routes/post')

app.use('/posts', postRoute)
app.use('/users', authRoute)

app.get("/",()=>{
datetext = new Date().toTimeString().split(' ')[0];
console.log(datetext);

}) 
const port=process.env.PORT || 3000
app.listen(port, () => {
    console.log("I am running");
})