const mongoose = require('mongoose')

const postSchema = new mongoose.Schema({
    toDo: {
        type: String,
        max: 250,
        min: 2,
        required: true
    },
    place: {
        type: String,
        max: 100,
        min: 2,
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    meetingTime: {
        type: String,
        required: true
    },
    timeOut: {
        type: Number,
        required: true 
    },
    postTime: { 
        type: string,
        default: new Date().getHours()    
    }
},)


module.exports = mongoose.model('Board', postSchema)
